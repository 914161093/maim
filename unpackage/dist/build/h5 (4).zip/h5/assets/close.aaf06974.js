const e=""+new URL("close-32ee37fd.svg",import.meta.url).href;export{e as _};
