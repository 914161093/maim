const a=""+new URL("car-7fa7ac6a.png",import.meta.url).href;export{a as _};
