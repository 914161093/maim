const e=""+new URL("luck_bg-238fb81d.png",import.meta.url).href,p=""+new URL("pip_fail-8c4f7651.png",import.meta.url).href;export{e as _,p as a};
