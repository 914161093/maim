const e=""+new URL("luck_bg-238fb81d.png",import.meta.url).href;export{e as _};
