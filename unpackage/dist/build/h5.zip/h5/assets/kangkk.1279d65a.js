const e=""+new URL("kangkk-e8a7bef3.png",import.meta.url).href;export{e as _};
